#include<stdio.h>
void welcome(void);
void printfSquare(int side, char ch);
int main()
{
	int side;
	char ch;
	
	welcome();
	
	printf("Enter side: ");
	scanf("%d", &side);
	printf("Enter character: ");
	scanf(" %c", &ch);
	

	printfSquare(side,ch);
	welcome();
	
	return 0;
}
void welcome(void) // no arguments, no return value
{
	printf("=====================================\n");
	printf("\tPattern Printer v1.0\n");
	printf("=====================================\n");
}
void printfSquare(int side, char ch) // arguments, no return value
{
	int i,j;
	
	for(i=1;i<=side;i++)
	{
		for(j=1;j<=side;j++) 
			printf(" %c", ch);
		printf("\n");
	}
	
}
	
