#include<stdio.h>
int prime(int n);
int perfect(int n);
int reversenumber(int n);
int palindrome(int n);
int digitsum(int n);
void report(int n);
int main()
{
	int n;
	printf("Enter a positive number: ");
	scanf("%d",&n);
	
	report(n);
	
	return 0;
}
int prime(int n) // Arguments and returns a value;
{
	int i;
	
	if(n<=1)
		return 0;
		
	for(i=2; i<n;i++)
	{
		if(n%i==0)
			return 0;
	}	
	
	return 1;
}
int perfect(int n)// Arguments and returns a value;
{
	int i, sum =0;
	
	for(i=1;i<n;i++)
	{
		if(n%i==0)
			sum = sum+i;
	}	
	
	if(sum==n)
		return 1;
	else
		return 0;
}
int reversenumber(int n) // Arguments and returns value;
{
	int rev=0, digit;
	
	while(n>0)
	{
		digit = n%10;
		rev = rev *10 +digit;
		n = n/10;
	}
	
	return rev;
}
int palindrome(int n) // Arguments and returns value;
{
	if(n== reversenumber(n))
		return 1;
	else
		return 0;
}
int digitsum(int n) // Arguments and returns value;
{
	int sum=0;
	
	while(n>0)
	{
		sum = sum +n %10;
		
		n = n/10;
	}
	return sum;
}
void report(int n)
{
	int i;
	
	if(prime(n))
		printf("Prime: Yes \n");
	else 
		printf("Prime: No \n");
		
	if(perfect(n))
		printf("Perfect: Yes \n");
	else
		printf("Perfect: No \n");
		
	printf("Reverse: %d\n", reversenumber(n));
	
	if(palindrome(n))
		printf("Palindrome: Yes \n");
	else
		printf("Palindrome: No \n");
	
	printf("Sum of digits: %d\n", digitsum(n));
	
	printf("Prime from 1 to %d: ", n);
	
	for(i=1;i<=n;i++)
	{
		if(!prime(i))
			continue;
			
		printf("%d ", i);
	}
	
	printf("\n");
}



















