#include<stdio.h>
#include<math.h>
int main()
{
	double a,b,c, roundedup, roundeddown, area;
	
	printf("Enter value a: ");
	scanf("%lf", &a);
	printf("Enter value b: ");
	scanf("%lf", &b);
	
	c = sqrt(pow(a,2)+pow(b,2)); 
	roundedup = ceil(c) ;
	roundeddown = floor(c) ;
	area =  (float) 1/2 * a * b;
	
	// sqrt() == header file: math.h; type double;
	// pow() == header file: math.h; type double;
	// ceil() == header file: math.h; type double;
	// floor() == header file: math.h; type double;
	
	printf("%.2lf \n", c);
	printf("%.2lf \n", roundedup);
	printf("%.2lf \n", roundeddown);
	printf("%.2lf", area);
	
	return 0;
}
