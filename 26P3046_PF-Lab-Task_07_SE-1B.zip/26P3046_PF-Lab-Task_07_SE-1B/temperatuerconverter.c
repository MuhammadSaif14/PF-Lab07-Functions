#include<stdio.h>
float toFarenheit(float c);
float toCelsius(float f);
void printTable(int start, int end, int step);
int main()
{
	int start, end, step;
	float f;
	
	printf("Start: ");
	scanf("%d", &start);
	printf("End: ");
	scanf("%d", &end);
	printf("Step: ");
	scanf("%d", &step);
	
	printTable(start,end,step);
	
	printf("Enter a temperature in farenheit:  ");
	scanf("%f", &f);
	
	printf("%.1f F = %.2f C \n",f,toCelsius(f));
	
	return 0;
}
float toFarenheit(float c)
{
	return (c*9)/5 + 32;
}
float toCelsius(float f)
{
	return (f-32) * 5/9;
}
void printTable(int start, int end, int step)
{
	int i;
	
	printf("Celsius \t Farenheit\n");
	
	for(i=start;i<=end;i= i+step)
		printf("%7d \t %10.1f\n", i, toFarenheit(i));
}
