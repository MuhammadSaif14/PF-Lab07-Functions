#include<stdio.h>
int readUnits(void);
float calculateBill(int units);
int main()
{
	int units;
	float total;
	
	units = readUnits();
	total = calculateBill(units);
	
	printf("Units consumed: %d\n", units);
	printf("Total bill: %f", total);
	
	return 0;
}
int readUnits(void) // no arguments and returns value;
{	
	int units;
	printf("Enter units consumed: ");
	scanf("%d", &units);
	
	while(units<0)
	{
		printf("Units cannot be negative! \n");
		printf("Enter units consumed: ");
		scanf("%d", &units);
	}
	
	return units;
}
float calculateBill(int units)  //Arguments and returns a value;
{
	float total;

	if(units<=100)
		total = units * 10;
	else if(units<=300)
		total = 100*10 + (units-100)*15;
	else
		total = 100*10 + 200 * 15 + (units-300)*20;
		
	if(total>3000)
		total = total + total * 0.05;
		
	return total;
}

//calculateBill returns the bill so that main()
//can display it. This separates calculation
//from output.
